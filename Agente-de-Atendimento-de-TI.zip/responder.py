import json
import re
import unicodedata
from pathlib import Path


_BASE_RESPOSTAS = json.loads(
    Path(__file__).with_name("respostas.json").read_text(encoding="utf-8")
)
_CPF = re.compile(r"(?<!\d)\d{3}\.?\d{3}\.?\d{3}-?\d{2}(?!\d)")
_CREDENCIAL = re.compile(
    r"\b(?:senha|password|token|chave\s+de\s+api|api\s+key|"
    r"c[oó]digo\s+de\s+autentica[cç][aã]o)\s*(?:(?:é|e|:|=)\s*)\S+",
    re.IGNORECASE,
)
_CATEGORIAS_PRIORITARIAS = (
    "incidente_seguranca",
    "atendimento_humano",
    "aprovacao_ou_permissao",
    "divergencia_licenciamento",
    "consulta_status",
    "problema_tecnico",
    "equipamentos",
    "licenca_software",
    "saudacao",
)


def _normalizar(texto: str) -> str:
    decomposed = unicodedata.normalize("NFKD", texto.casefold())
    sem_acentos = "".join(
        caracter for caracter in decomposed if not unicodedata.combining(caracter)
    )
    return re.sub(r"[^a-z0-9]+", " ", sem_acentos).strip()


def _corresponde(texto: str, termos: list[str]) -> bool:
    texto_normalizado = f" {_normalizar(texto)} "
    return any(
        f" {_normalizar(termo)} " in texto_normalizado
        for termo in termos
    )


def _mensagem_tem_dado_sensivel(texto: str) -> bool:
    return bool(_CPF.search(texto) or _CREDENCIAL.search(texto))


def _canal_ja_informado(mensagens: list[dict[str, str]]) -> bool:
    termos_canal = _BASE_RESPOSTAS["termos_canal"]
    return any(
        mensagem["role"] == "user"
        and _corresponde(mensagem["content"], termos_canal)
        for mensagem in mensagens[:-1]
    )


def gerar_resposta(mensagens: list[dict[str, str]]) -> str:
    texto_atual = mensagens[-1]["content"]
    if _mensagem_tem_dado_sensivel(texto_atual):
        return _BASE_RESPOSTAS["respostas"]["credencial"]

    categorias = _BASE_RESPOSTAS["categorias"]
    for categoria in _CATEGORIAS_PRIORITARIAS:
        if _corresponde(texto_atual, categorias[categoria]["termos"]):
            if categoria == "saudacao":
                saudacoes = {
                    _normalizar(termo)
                    for termo in categorias["saudacao"]["termos"]
                }
                if _normalizar(texto_atual) not in saudacoes:
                    continue
            resposta = categorias[categoria]["resposta"]
            if categoria == "consulta_status" and _canal_ja_informado(mensagens):
                return resposta.replace(
                    "Qual canal oficial foi indicado?",
                    "Consulte o canal oficial que você informou.",
                )
            return resposta
    return _BASE_RESPOSTAS["respostas"]["fora_escopo"]
