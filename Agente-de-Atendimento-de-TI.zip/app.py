from pathlib import Path

from flask import Flask, jsonify, render_template, request, send_file
from responder import gerar_resposta


ROOT_DIR = Path(__file__).resolve().parent
MAX_MESSAGE_LENGTH = 4000
MAX_HISTORY_MESSAGES = 12

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 64 * 1024


def validate_messages(payload: object) -> list[dict[str, str]]:
    if not isinstance(payload, list) or not payload:
        raise ValueError("Envie pelo menos uma mensagem.")

    messages = payload[-MAX_HISTORY_MESSAGES:]
    validated = []
    for message in messages:
        if not isinstance(message, dict):
            raise ValueError("O formato das mensagens é inválido.")
        role = message.get("role")
        content = message.get("content")
        if role not in {"user", "assistant"} or not isinstance(content, str):
            raise ValueError("O formato das mensagens é inválido.")
        content = content.strip()
        if not content or len(content) > MAX_MESSAGE_LENGTH:
            raise ValueError("Cada mensagem deve ter entre 1 e 4.000 caracteres.")
        validated.append({"role": role, "content": content})

    if validated and validated[0]["role"] == "assistant":
        validated = validated[1:]
    if not validated or validated[-1]["role"] != "user":
        raise ValueError("A última mensagem precisa ser do usuário.")
    if any(
        previous["role"] == current["role"]
        for previous, current in zip(validated, validated[1:])
    ):
        raise ValueError("As mensagens da conversa estão fora de ordem.")
    return validated


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/capa.png")
def cover_image():
    return send_file(ROOT_DIR / "img" / "capa-agente-atendimento-ti.png")


@app.post("/api/chat")
def chat():
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify(error="Envie uma solicitação JSON válida."), 400

    try:
        messages = validate_messages(payload.get("messages"))
    except ValueError as error:
        return jsonify(error=str(error)), 400

    return jsonify(reply=gerar_resposta(messages))


if __name__ == "__main__":
    app.run(debug=False)
