# Agente de Atendimento de TI

Projeto educacional desenvolvido a partir do desafio de criação de um agente de atendimento da DIO.

O chat local foi feito em Python (Flask) e HTML. As respostas automáticas são selecionadas por palavras-chave configuradas em [`respostas.json`](respostas.json), seguindo as orientações de [`prompt.md`](prompt.md). A Aurora Digital é fictícia.

## Requisitos

- Python 3.10 ou superior
- Nenhuma chave de API ou conexão com serviços de IA

## Configuração no Windows

No PowerShell, na pasta do projeto:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```

Abra <http://127.0.0.1:5000>. As mensagens são processadas no próprio computador e não são enviadas a serviços externos. Como não há IA, perguntas que não correspondam às regras recebem a resposta padrão. Ajuste ou amplie as respostas e palavras-chave em `respostas.json`.

O aplicativo não acessa sistemas corporativos, não aprova solicitações e não abre nem encaminha chamados. Para status, disponibilidade e outros dados internos, orienta a consulta à equipe responsável.

## Baixar o projeto

[Baixar todos os arquivos em ZIP](https://github.com/sauloprado/Agente-de-Atendimento-de-TI/archive/refs/heads/main.zip) ou abra o repositório no GitHub e escolha **Code > Download ZIP**.

## Testes

```powershell
python -m unittest discover -s tests
```

## Autor

Saulo Prado
