const form = document.querySelector("#chat-form");
const input = document.querySelector("#message-input");
const messagesElement = document.querySelector("#messages");
const sendButton = document.querySelector("#send-button");
const suggestions = document.querySelector("#suggestions");
const clearButton = document.querySelector("#clear-chat");

const history = [];
const greeting = "Olá! Posso orientar sobre licenças, equipamentos ou como descrever um problema técnico. Como posso ajudar?";

function addMessage(role, text, { temporary = false } = {}) {
  const message = document.createElement("div");
  message.className = `message ${role === "user" ? "user-message" : "assistant-message"}`;
  if (temporary) message.classList.add("typing");

  if (role === "assistant") {
    const avatar = document.createElement("div");
    avatar.className = "message-avatar";
    avatar.setAttribute("aria-hidden", "true");
    avatar.textContent = "A";
    message.append(avatar);
  }

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  const paragraph = document.createElement("p");
  paragraph.textContent = text;
  bubble.append(paragraph);
  if (!temporary) {
    const time = document.createElement("time");
    time.textContent = new Intl.DateTimeFormat("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
    }).format(new Date());
    bubble.append(time);
  }
  message.append(bubble);
  messagesElement.append(message);
  messagesElement.scrollTop = messagesElement.scrollHeight;
  return message;
}

async function sendMessage(text) {
  const content = text.trim();
  if (!content || sendButton.disabled) return;

  history.push({ role: "user", content });
  addMessage("user", content);
  input.value = "";
  input.style.height = "auto";
  suggestions.hidden = true;
  sendButton.disabled = true;
  input.disabled = true;
  const pending = addMessage("assistant", "Consultando as respostas locais...", { temporary: true });

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: history }),
    });
    const data = await response.json();
    pending.remove();
    if (!response.ok) throw new Error(data.error || "Não foi possível responder agora.");
    if (data.sensitive) history.pop();
    else history.push({ role: "assistant", content: data.reply });
    addMessage("assistant", data.reply);
  } catch (error) {
    pending.remove();
    history.pop();
    addMessage("assistant", error.message || "Não foi possível responder agora. Tente novamente.");
  } finally {
    sendButton.disabled = false;
    input.disabled = false;
    input.focus();
  }
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  sendMessage(input.value);
});

input.addEventListener("input", () => {
  input.style.height = "auto";
  input.style.height = `${Math.min(input.scrollHeight, 130)}px`;
});

input.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});

suggestions.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-prompt]");
  if (button) sendMessage(button.dataset.prompt);
});

clearButton.addEventListener("click", () => {
  history.length = 0;
  messagesElement.replaceChildren();
  addMessage("assistant", greeting);
  suggestions.hidden = false;
  input.value = "";
  input.focus();
});
