import unittest

import app


class ChatEndpointTests(unittest.TestCase):
    def setUp(self):
        app.app.config["TESTING"] = True
        self.client = app.app.test_client()

    def responder(self, text):
        return self.client.post(
            "/api/chat",
            json={"messages": [{"role": "user", "content": text}]},
        )

    def test_license_question_uses_local_guidance(self):
        response = self.responder("Como solicito uma licença de software?")
        self.assertEqual(response.status_code, 200)
        self.assertIn("nome do software", response.json["reply"])
        self.assertIn("finalidade de uso", response.json["reply"])

    def test_technical_issue_gets_ticket_description_steps(self):
        response = self.responder("Estou com um problema técnico no computador")
        self.assertEqual(response.status_code, 200)
        self.assertIn("mensagem de erro", response.json["reply"])
        self.assertIn("1.", response.json["reply"])

    def test_equipment_question_does_not_claim_availability(self):
        response = self.responder("Quero solicitar um notebook")
        self.assertEqual(response.status_code, 200)
        self.assertIn("disponibilidade", response.json["reply"])
        self.assertNotIn("temos disponível", response.json["reply"].lower())

    def test_status_query_explains_lack_of_access_and_asks_for_channel(self):
        response = self.responder("Quero consultar o status da solicitação")
        self.assertEqual(response.status_code, 200)
        self.assertIn("Não tenho acesso", response.json["reply"])
        self.assertIn("Qual canal oficial", response.json["reply"])

    def test_previously_provided_channel_is_not_asked_again(self):
        response = self.client.post(
            "/api/chat",
            json={
                "messages": [
                    {"role": "user", "content": "O canal oficial é o portal interno"},
                    {"role": "assistant", "content": "Entendi."},
                    {
                        "role": "user",
                        "content": "Quero consultar o status da solicitação",
                    },
                ]
            },
        )
        self.assertEqual(response.status_code, 200)
        self.assertNotIn("Qual canal oficial", response.json["reply"])
        self.assertIn("canal oficial que você informou", response.json["reply"])

    def test_security_incident_gets_human_guidance(self):
        response = self.responder("Recebi uma mensagem de phishing")
        self.assertEqual(response.status_code, 200)
        self.assertIn("interrompa a interação suspeita", response.json["reply"])
        self.assertIn("não realizando uma transferência", response.json["reply"])

    def test_credential_is_not_repeated_in_response(self):
        response = self.responder("Minha senha é segredo123")
        self.assertEqual(response.status_code, 200)
        self.assertNotIn("segredo123", response.json["reply"])
        self.assertIn("não vou repetir", response.json["reply"])

    def test_invalid_message_order_is_rejected(self):
        response = self.client.post(
            "/api/chat",
            json={
                "messages": [
                    {"role": "user", "content": "Olá"},
                    {"role": "user", "content": "Mais uma mensagem"},
                ]
            },
        )

        self.assertEqual(response.status_code, 400)

    def test_page_explains_that_replies_are_local(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("não são enviadas a uma IA".encode(), response.data)

    def test_responses_have_at_most_five_nonempty_lines(self):
        for text in (
            "Bom dia",
            "Quero uma licença de software",
            "Como consultar o status do chamado?",
            "Estou com um problema técnico",
            "Quero falar com uma pessoa",
            "Recebi um phishing",
            "Minha senha é segredo123",
        ):
            with self.subTest(text=text):
                reply = self.responder(text).json["reply"]
                nonempty_lines = [line for line in reply.splitlines() if line.strip()]
                self.assertLessEqual(len(nonempty_lines), 5)


if __name__ == "__main__":
    unittest.main()
